<?php
/**
 * 
 * @included from - class-ht-ctc-chat.php
 * 
 * position to place .. 
 */



$side_1 = esc_attr( $options['side_1'] );
$side_1_value = esc_attr( $options['side_1_value'] );

$side_2 = esc_attr( $options['side_2'] );
$side_2_value = esc_attr( $options['side_2_value'] );

$position = "$side_1: $side_1_value; $side_2: $side_2_value;";