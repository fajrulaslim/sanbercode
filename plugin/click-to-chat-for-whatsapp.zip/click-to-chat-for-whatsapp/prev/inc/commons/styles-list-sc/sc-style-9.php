<?php

if ( ! defined( 'ABSPATH' ) ) exit;

$s9_icon_size = $a['s9_icon_size'];


$s9_icon_size = $s9_icon_size;

$o .= '<div class="ccw_plugin '.$inline_issue.' ">';
$o .= '<img class="img-icon-sc sc_item pointer style-3-sc ccw-analytics" data-ccw="style-9-sc" src="'.$img_link_s9.'" alt="WhatsApp chat" onclick="'.$img_click_link.'" style="height: '.$s9_icon_size.'; '.$css.' " >';
$o .= '</div>';